Buzz Time

Video Demonstration: https://www.youtube.com/watch?v=IHVgZemCajw

-- An app for testing personal reaction times and also doubles as a mutiplaer gameshow buzzer.  Statistics
	and metrics are kept track of and you are even able to share them via email!

-- an application for Assignment #1 of CMPUT 301, Fall Semester 2015 at the University of Alberta


Sources:
	
- Gson load and save files taken from CMPUT 301 lab sections taught by Joshua Charles Campbell (GitHub https://github.com/joshua2ua)

- Code for sending statistic email I consulted: http://www.tutorialspoint.com/android/android_sending_email.htm
	- Author for the article could not be found

- Code for avoiding button bounce I consulted http://stackoverflow.com/questions/5608720/android-preventing-double-click-on-a-button
	- Specifically I consulted the top response written by "qzet"

- Discussions were had among peers: edcarter, jtdavids, and sdwowk



License:

	Copyright 2015 Joshua White

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	    http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.